import database from '../config/connection.js';
import { DataTypes} from "sequelize";

const Client = database.define('Client', {
    id_client: {type: DataTypes.INT, allowNull: false, unique: true},
    nom: {type: DataTypes.STRING, allowNull: false},
    prenom: {type: DataTypes.STRING, allowNull: false},
    article_prefere: {type: DataTypes.STRING, allowNull:false}
})

export default Client