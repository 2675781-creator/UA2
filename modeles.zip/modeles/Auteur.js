import database from '../config/connection.js';
import { DataTypes} from "sequelize";

const Auteur = database.define('Auteur', {
    numero_auteur: {type: DataTypes.INT, allowNull: false, unique:true},
    nom: {type: DataTypes.STRING, allowNull: false},
    prenom: {type: DataTypes.STRING, allowNull: false},
    age: {type: DataTypes.INT, allowNull: false},
    nationalite: {type: DataTypes.STRING, allowNull: false},
    langue: {type: DataTypes.STRING, allowNull: false}
})

export default Auteur