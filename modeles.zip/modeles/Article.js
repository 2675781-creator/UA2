import database from '../config/connection.js';
import { DataTypes} from "sequelize";

const Article = database.define('Article', {
    numero_article: {type: DataTypes.INT, allowNull:false},
    titre: {type: DataTypes.STRING, allowNull:false, unique: true},
    date_publication: DataTypes.DATEONLY,
    status : {type : DataTypes.STRING, allowNull:false},
    quantite : {type : DataTypes.INT, allowNull: false}
});

export default Article