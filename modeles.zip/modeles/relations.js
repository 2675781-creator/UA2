import Auteur from "./Auteur.js";
import Article from "./Article.js";
import Categorie from "./categorie.js";
import Client from "./Client.js";
import Employe from "./Employe.js";


//un auteur a plusieurs articles
Auteur.hasMany(Article)

//un article peut se situe dans plusieurs catégories
Article.hasMany(Categorie)

//un client peut emprunté plusieurs articles
Client.hasMany(Article)

//Un article peut etre gere par plusieurs employe
Article.hasMany(Employe)