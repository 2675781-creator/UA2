import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import dotenv from 'dotenv';


import database from './config/connection.js'

const app = express()

//Utilisation des middlewares globaux
app.use(helmet())
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({extended: true}))

// Démarrer le serveur

const ENV = dotenv.config().parsed;

const PORT= ENV.PORT || 8000
// console.log("variables d'environement :", ENV);


// Creation des tables
database.sync({ alter: true })  //alter: modifie une table
                                //force : refaire toute la table

app.listen(PORT, () => {
    console.log(`Le serveur est demarre sur le port ${PORT}`)
})